--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.1
-- Dumped by pg_dump version 9.5.1

-- Started on 2016-03-31 21:44:14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12355)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2116 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 181 (class 1259 OID 16423)
-- Name: images; Type: TABLE; Schema: public; Owner: christophe
--

CREATE TABLE images (
    id_tag integer NOT NULL,
    path_image text NOT NULL
);


ALTER TABLE images OWNER TO christophe;

--
-- TOC entry 182 (class 1259 OID 16429)
-- Name: tags; Type: TABLE; Schema: public; Owner: christophe
--

CREATE TABLE tags (
    tag_name text,
    id integer NOT NULL
);


ALTER TABLE tags OWNER TO christophe;

--
-- TOC entry 183 (class 1259 OID 16435)
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: christophe
--

CREATE SEQUENCE tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tags_id_seq OWNER TO christophe;

--
-- TOC entry 2117 (class 0 OID 0)
-- Dependencies: 183
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: christophe
--

ALTER SEQUENCE tags_id_seq OWNED BY tags.id;


--
-- TOC entry 1987 (class 2604 OID 16437)
-- Name: id; Type: DEFAULT; Schema: public; Owner: christophe
--

ALTER TABLE ONLY tags ALTER COLUMN id SET DEFAULT nextval('tags_id_seq'::regclass);


--
-- TOC entry 2106 (class 0 OID 16423)
-- Dependencies: 181
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: christophe
--

COPY images (id_tag, path_image) FROM stdin;
4	content\\animaux\\chaton.jpg
4	content\\animaux\\koala.jpg
4	content\\animaux\\singe.jpg
1	content\\avions\\boeing.jpg
1	content\\avions\\avion de chasse.jpeg
4	content\\animaux\\petit cochon.jpg
1	content\\avions\\boeing747.jpg
1	content\\avions\\vol-avion-de-chasse-amiens.jpg
1	content\\avions\\concorde.jpg
1	content\\avions\\vol-avion-de-chasse-rennes.jpg
4	content\\animaux\\petit chien.jpg
4	content\\animaux\\bebe panda.jpg
1	content\\avions\\concorde decolage.jpg
2	content\\super-heros\\batman.jpg
2	content\\super-heros\\batman_share.jpg
2	content\\super-heros\\Coloriage-Spiderman.jpg
2	content\\super-heros\\lead_960.jpg
2	content\\super-heros\\lego superman.png
2	content\\super-heros\\spiderman.jpg
2	content\\super-heros\\Superman.jpg
2	content\\super-heros\\symbole spiderman.jpeg
3	content\\voitures\\bmw-i8.jpg
3	content\\voitures\\bugatti-veyron.jpg
3	content\\voitures\\lamborghini-aventador.jpg
3	content\\voitures\\renault-4l1.jpg
3	content\\voitures\\S7-modele--bmw-i8.jpg
\.


--
-- TOC entry 2107 (class 0 OID 16429)
-- Dependencies: 182
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: christophe
--

COPY tags (tag_name, id) FROM stdin;
Avions	1
Voitures	3
Animaux	4
Super-heros	2
\.


--
-- TOC entry 2118 (class 0 OID 0)
-- Dependencies: 183
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: christophe
--

SELECT pg_catalog.setval('tags_id_seq', 4, true);


--
-- TOC entry 1989 (class 2606 OID 16439)
-- Name: images_pkey; Type: CONSTRAINT; Schema: public; Owner: christophe
--

ALTER TABLE ONLY images
    ADD CONSTRAINT images_pkey PRIMARY KEY (path_image);


--
-- TOC entry 1991 (class 2606 OID 16441)
-- Name: tags_pkey; Type: CONSTRAINT; Schema: public; Owner: christophe
--

ALTER TABLE ONLY tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- TOC entry 2115 (class 0 OID 0)
-- Dependencies: 7
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2016-03-31 21:44:15

--
-- PostgreSQL database dump complete
--

