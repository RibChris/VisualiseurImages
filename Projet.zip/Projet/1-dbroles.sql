--
-- PostgreSQL database cluster dump
--

-- Started on 2016-03-31 21:40:49

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE christophe;
ALTER ROLE christophe WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION NOBYPASSRLS PASSWORD 'md511a955d104c45c88352e77a11ef1254a' VALID UNTIL 'infinity';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md5322c988fc030003dd1e571aef9c73bac';






-- Completed on 2016-03-31 21:40:49

--
-- PostgreSQL database cluster dump complete
--

