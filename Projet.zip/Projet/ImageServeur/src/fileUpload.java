

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Servlet implementation class fileUpload
 */
public class fileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private final String UPLOAD_DIRECTORY = "C:/Projet/ImageServeur/WebContent/content/upload";
	private final String CONTENT_DIRECTORY = "C:/Projet/ImageServeur/WebContent/content";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public fileUpload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean isMultipart = ServletFileUpload.isMultipartContent(request); //voir doc de jquery form
		String uploadTag="";
				 
        // process only if it is multipart content
        if (isMultipart) {
                // Create a factory for disk-based file items
                FileItemFactory factory = new DiskFileItemFactory();

                // Create a new file upload handler
                ServletFileUpload upload = new ServletFileUpload(factory);
                try {
                	// Parse the request
                	List<FileItem> multiparts = upload.parseRequest(request);

                	//On recherche le champ 'Combobox1'
                	for (FileItem item : multiparts) {
                		if (item.isFormField()) {
                			String fieldName = item.getFieldName();                			
                			if (fieldName.compareTo("Combobox1")==0)
                				uploadTag = item.getString();
                		}
                	}
                	if(uploadTag.isEmpty())
                		return;
                	
                	//Charge le fichier dans le dossier 'upload'
                	String fileName="";
                	for (FileItem item : multiparts) {
                		if (!item.isFormField()) {
                			fileName = new File(item.getName()).getName();
                			item.write(new File(UPLOAD_DIRECTORY + File.separator + fileName));
                		}
                	}
                	
                	//Deplacement du fichier dans le dossier du TAG
                	try{
                 	   File afile =new File(UPLOAD_DIRECTORY + File.separator + fileName);
                 		
                 	   if(afile.renameTo(new File(CONTENT_DIRECTORY+File.separator+uploadTag+File.separator+ afile.getName()))){
                 		   System.out.println("File is moved successful!");
                 	   }else{
                 		   System.out.println("File is failed to move!");
                 	   }
                 	    
                 	}catch(Exception e){
                 		e.printStackTrace();
                 	}

                	//Insertion dans la base de donnees
                	insertFileToDatabase(uploadTag,fileName);
                } 
                catch (Exception e) 
                {
                  e.printStackTrace();
                }
        }
	}

	private boolean insertFileToDatabase(String uploadTag, String fileName)
	{
		Connection c = null;
	    Statement stmt = null;
		int idTag=0;

		switch(uploadTag)
		{
			case "avions": idTag=1;break;
			case "super-heros": idTag=2;break;
			case "voitures": idTag=3;break;
			case "animaux": idTag=4;break;
			default: return false;
		}
		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/images","christophe", "azerty");
			c.setAutoCommit(false);
 
			stmt = c.createStatement();
			String sql = "INSERT INTO images (id_tag,path_image) VALUES "+
			"("+idTag+",'content\\"+uploadTag+"\\"+fileName+"');";
			stmt.executeUpdate(sql);

			stmt.close();
			c.commit();
			c.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
		}
	      
		return true;
	}
}
