

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Servlet implementation class getAllImages
 */

public class getAllImages extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getAllImages() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection c = null;
	    Statement stmt = null;
	     
	    int idSearchTag;
	    try{
	    	idSearchTag = Integer.parseInt(request.getParameter("searchTag"));
	    }
	    catch(Exception e)
	    {
	    	idSearchTag=0;
	    }

	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager.getConnection("jdbc:postgresql://127.0.0.1:5432/images","christophe", "azerty");
	         c.setAutoCommit(false);
	         
	         stmt = c.createStatement();
	         String requete;
	         if(idSearchTag==0)
	        	 requete="SELECT images.path_image, tags.tag_name FROM public.images, public.tags WHERE images.id_tag = tags.id;";
	         else
	        	 requete="SELECT images.path_image, tags.tag_name FROM public.images, public.tags WHERE images.id_tag = tags.id AND images.id_tag = "+idSearchTag+";";

	         ResultSet rs = stmt.executeQuery(requete);
	         
	         //Reponse JSON
	         JSONArray listOfImages = new JSONArray();  
		     PrintWriter out = response.getWriter();
        
	         while (rs.next()) {
	        	 JSONObject json=new JSONObject();
	        	 
	        	 json.put("Tag",rs.getString("tag_name"));
	        	 
	        	 String pathImage=rs.getString("path_image");
	        	 json.put("Image",pathImage.replace("\\", "\\\\")); //Important pour variable en javascript
	        	 
	        	 int idx=pathImage.lastIndexOf('\\');
	        	 if(idx==-1)
	        		 idx=0;
	        	 json.put("Name",pathImage.substring(idx+1));
	        	 listOfImages.put(json);
	          }
	          rs.close();
	          stmt.close();
	          c.close();

	          response.setHeader("Content-Type", "application/json; charset=ISO8859-1");
	          response.setContentType("application/json");
	          out.print(listOfImages.toString());
	          
//	          System.out.println("JSON : "+listOfImages.toString());
	          
	          out.flush();
	          out.close();
	      } catch (Exception e) {
	         e.printStackTrace();
	         System.err.println(e.getClass().getName()+": "+e.getMessage());
	         System.exit(0);
	      }
	}

}
