//Reload les donnees en fonction du menu choisi
//0->ALL ; 1->Avions ; 2->Super-Heros ; 3->Voitures ; 4->Animaux
function refreshDatatable(idTag) {
	switch(idTag)
	{
		case 0: document.getElementById('label_categorie').innerHTML ="All"; break;
		case 1: document.getElementById('label_categorie').innerHTML ="Avions"; break;
		case 2: document.getElementById('label_categorie').innerHTML ="Super-Heros"; break;
		case 3: document.getElementById('label_categorie').innerHTML ="Voitures"; break;
		case 4: document.getElementById('label_categorie').innerHTML ="Animaux"; break;
	}

	//Reload des donnees
	datatable.ajax.url( "getAllImages?searchTag="+idTag).load();
}

function openfancybox(url)
{
	$.fancybox.open([
	                 {
	                	 href : ''+url+'',                
	                 },
	                ],
	                {
        				padding : 0
	                }
	);
	
	return false;
}
// initialisation datatable
$(document).ready(function() {
	datatable = $('#imgtable').DataTable({
			"bAutoWidth": false,
			"ajax": {
				"url": "getAllImages",
				"dataType": "json",
				"cache": false,
				"type": "POST",
				"dataSrc": "", //problème si non présent
				"data": {
			           	"searchTag": "0" // demande de toutes les images (case 0)
						}
					},
				"columns": [
				            {"width": "20%", "searchable": false, "data": "Tag" },
				            {"width": "20%", "searchable": false, "sortable": false, "data": "Image" },
				            {"width": "60%", "data": "Name" },
				            ],
				"fnRowCallback": function( nRow, data, iDisplayIndex ) { // charger l'image dans la datatable et gérer le clique pour afficher l'image en grand
                    $('td:eq(1)', nRow).html('<a onclick="openfancybox('+"'"+data["Image"]+"'"+');" href="#"><img height="50" width="50" src="'+data["Image"]+'"/></a>');
                    return nRow;
				}
	});
});
